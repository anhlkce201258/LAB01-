`pragma protect begin_protected
`pragma protect version="1.0"
`pragma protect author="default"
`pragma protect author_info="default"
`pragma protect encrypt_agent="GOWIN"
`pragma protect encrypt_agent_info="GOWIN Encrypt Version 1.0"

`pragma protect encoding=(enctype="base64", line_length=76, bytes=256)
`pragma protect key_keyowner="GOWIN",key_keyname="GWK2022-11",key_method="rsa"
`pragma protect key_block
NLzhtcCvmaaiu3530/l+XX4dknM9yKIxrO7bazYYFJyehZfio/PFnN0MRnsW0JgiyQG6nHrc5gAT
gqWYT55TSh4UFoPd6JFJvgY94pwfPgdYXaMi/rdM8U0K9s9tccGtxO0HKfULc8C2Hisuu9/+43+I
uuWN+GXx9w9ORi81gy4S8CmKFm+o9ywVYlZsd9CK5RtttxAOmCWGeb7T0OsOLJawqLDwZUWuWztf
oQykN4s3F+pn15kNTzrEGAyQn0krF/HpAkhw8PKyvRHeS2kgN7nZ97QLKIuqsqXcNb7l+BtlGyBa
0XF2B5aJxYmqXNsLUD1a/3Rx73AbpQbDaPnvIQ==

`pragma protect encoding=(enctype="base64", line_length=76, bytes=368)
`pragma protect data_keyowner="default-ip-vendor"
`pragma protect data_keyname="default-ip-key"
`pragma protect data_method="aes128-cbc"
`pragma protect data_block
eBNfUHLcHBCI1rfnVMYw3TQSQLct3a8/UPK31zPjtXk0AB82Ar529v5muNH3iZeX9UhgFgsEsL/o
BAxgiALKcHOIehyTBQxqy9DVXKTCw0vebR72J7Jkn9mXgxC+wyihINlZZLvfyMiMQr7NPBKr60f2
ijFJuACXamEmJg5Qt3WsJoSVmr48TtjEFZc8WvW+lrqX0Hx7eImpMAzKXLJ4zE+oBY/IDc2cQVNj
IK0qTzK7pmJgbXjdluIQwBlwF4Y6XWDHSFcNBNbC+GAI5K4+Nb9W0uFDCeVoIchFhlG9FVutAvO0
1ga0NsrbFJ+oE+szq6OAG/0ZairbQo0rYMOObuK8XqGOaCZB/nipkMtpnvhdYcTkLPXGBl4LCNz6
SgehZsm1zr55SB62DdI/I3ZVNCD+jdeNXtVzw5qUS7MtzBspE56kZ5wqh1QWyqTo1L/8pzIcAfd7
9emPaiVKc6sbT0fFCmjNYFZBU6dwfFq2FMc=
`pragma protect end_protected
